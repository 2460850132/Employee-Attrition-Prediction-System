EMPLOYEE ATTRITION PREDICTION SYSTEM — RUN INSTRUCTIONS

1. Extract this ZIP file.
2. Open the extracted Employee_Attrition_Project_FIXED folder in VS Code.
3. Open VS Code Terminal. Confirm terminal path is the project root (the folder containing app.py and model.pkl).
4. Run:
   python -m pip install -r requirements.txt
5. Then run:
   python app.py
6. Keep the terminal open while using the website.
7. Open http://127.0.0.1:5000 in Chrome.

If port 5000 is already in use, stop the other running Flask server with Ctrl+C in its terminal, then run python app.py again.

The frontend uses the same request fields expected by app.py: Age, Salary, Experience, Department, JobSatisfaction, OverTime.
The model output is an estimate and should not be used as the sole basis for HR decisions.
