from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import pickle
import pandas as pd
import sqlite3
from datetime import datetime

app = Flask(__name__)

CORS(app)


# ==============================
# Load trained ML model
# ==============================
with open("model.pkl", "rb") as file:
    model = pickle.load(file)


# ==============================
# Database Connection
# ==============================
def get_db_connection():

    conn = sqlite3.connect("employee_predictions.db")

    conn.row_factory = sqlite3.Row

    return conn


# ==============================
# Create Prediction Table
# ==============================
def create_database():

    conn = get_db_connection()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS predictions (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            age INTEGER,

            monthly_income INTEGER,

            total_working_years INTEGER,

            department TEXT,

            job_satisfaction INTEGER,

            overtime TEXT,

            prediction TEXT,

            probability REAL,

            risk_category TEXT,

            created_at TEXT

        )
    """)

    conn.commit()

    conn.close()


# Create database when application starts
create_database()


# ==============================
# HOME PAGE
# ==============================
@app.route("/")
def home():

    return send_from_directory(
        "frontend",
        "index.html"
    )


# ==============================
# PREDICTION API
# ==============================
@app.route("/predict", methods=["POST"])
def predict():

    try:

        # Get JSON data
        data = request.get_json()

        if not data:

            return jsonify({

                "success": False,

                "error": "No input data received."

            }), 400


        # ==============================
        # Required Fields
        # ==============================

        required_fields = [

            "Age",
            "Salary",
            "Experience",
            "Department",
            "JobSatisfaction",
            "OverTime"

        ]


        # Check required fields

        for field in required_fields:

            if field not in data or data[field] in ["", None]:

                return jsonify({

                    "success": False,

                    "error": f"{field} is required."

                }), 400


        # ==============================
        # Convert Numeric Values
        # ==============================

        try:

            age = int(data["Age"])

            salary = int(data["Salary"])

            experience = int(data["Experience"])

            job_satisfaction = int(
                data["JobSatisfaction"]
            )

        except (ValueError, TypeError):

            return jsonify({

                "success": False,

                "error":
                "Age, Salary, Experience and Job Satisfaction must be valid numbers."

            }), 400


        # ==============================
        # Validate Age
        # ==============================

        if age < 18 or age > 100:

            return jsonify({

                "success": False,

                "error":
                "Age must be between 18 and 100."

            }), 400


        # ==============================
        # Validate Salary
        # ==============================

        if salary <= 0:

            return jsonify({

                "success": False,

                "error":
                "Salary must be greater than 0."

            }), 400


        # ==============================
        # Validate Experience
        # ==============================

        if experience < 0:

            return jsonify({

                "success": False,

                "error":
                "Experience cannot be negative."

            }), 400


        # ==============================
        # Validate Job Satisfaction
        # ==============================

        if job_satisfaction not in [1, 2, 3, 4]:

            return jsonify({

                "success": False,

                "error":
                "Job Satisfaction must be between 1 and 4."

            }), 400


        # ==============================
        # Validate Department
        # ==============================

        department = str(
            data["Department"]
        ).strip()


        if not department:

            return jsonify({

                "success": False,

                "error":
                "Department is required."

            }), 400


        # ==============================
        # Validate Overtime
        # ==============================

        overtime = str(
            data["OverTime"]
        ).strip()


        if overtime not in ["Yes", "No"]:

            return jsonify({

                "success": False,

                "error":
                "OverTime must be Yes or No."

            }), 400


        # ==============================
        # Prepare Input Data
        # ==============================

        input_data = pd.DataFrame([{

            "Age": age,

            "MonthlyIncome": salary,

            "TotalWorkingYears": experience,

            "Department": department,

            "JobSatisfaction": job_satisfaction,

            "OverTime": overtime

        }])


        # ==============================
        # ML Prediction
        # ==============================

        prediction = model.predict(
            input_data
        )[0]


        # ==============================
        # Prediction Probability
        # ==============================

        probability = model.predict_proba(
            input_data
        )[0][1]


        # ==============================
        # Attrition Result
        # ==============================

        if prediction == 1:

            attrition_prediction = "Likely to Leave"

        else:

            attrition_prediction = "Likely to Stay"


        # ==============================
        # Risk Category
        # ==============================

        if probability >= 0.70:

            risk_category = "High Risk"

        elif probability >= 0.40:

            risk_category = "Medium Risk"

        else:

            risk_category = "Low Risk"


        # ==============================
        # Save Prediction
        # ==============================

        conn = get_db_connection()


        conn.execute("""

            INSERT INTO predictions (

                age,

                monthly_income,

                total_working_years,

                department,

                job_satisfaction,

                overtime,

                prediction,

                probability,

                risk_category,

                created_at

            )

            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)

        """, (

            age,

            salary,

            experience,

            department,

            job_satisfaction,

            overtime,

            attrition_prediction,

            round(
                probability * 100,
                2
            ),

            risk_category,

            datetime.now().strftime(
                "%Y-%m-%d %H:%M:%S"
            )

        ))


        conn.commit()

        conn.close()


        # ==============================
        # Prediction Confidence
        # ==============================
        # probability is the model's probability of attrition (Leave).
        # If the employee is predicted to Leave, the confidence is the
        # attrition probability. If predicted to Stay, the confidence is
        # the probability of Stay.
        attrition_probability = round(probability * 100, 2)

        if prediction == 1:
            prediction_confidence = attrition_probability
        else:
            prediction_confidence = round((1 - probability) * 100, 2)

        # ==============================
        # Send Result to Frontend
        # ==============================

        return jsonify({

            "success": True,

            "attrition_prediction":
            attrition_prediction,

            "attrition_probability":
            attrition_probability,

            "risk_category":
            risk_category,

            "prediction_confidence":
            prediction_confidence

        })


    except Exception as e:

        return jsonify({

            "success": False,

            "error": str(e)

        }), 500


# ==========================================================
# DASHBOARD API
# ==========================================================

@app.route("/dashboard-data", methods=["GET"])
def dashboard_data():

    try:

        conn = get_db_connection()


        # ==============================
        # Total Predictions
        # ==============================

        total_predictions = conn.execute("""

            SELECT COUNT(*) AS total

            FROM predictions

        """).fetchone()["total"]


        # ==============================
        # Likely to Leave
        # ==============================

        likely_to_leave = conn.execute("""

            SELECT COUNT(*) AS total

            FROM predictions

            WHERE prediction = 'Likely to Leave'

        """).fetchone()["total"]


        # ==============================
        # Likely to Stay
        # ==============================

        likely_to_stay = conn.execute("""

            SELECT COUNT(*) AS total

            FROM predictions

            WHERE prediction = 'Likely to Stay'

        """).fetchone()["total"]


        # ==============================
        # High Risk
        # ==============================

        high_risk = conn.execute("""

            SELECT COUNT(*) AS total

            FROM predictions

            WHERE risk_category = 'High Risk'

        """).fetchone()["total"]


        # ==============================
        # Medium Risk
        # ==============================

        medium_risk = conn.execute("""

            SELECT COUNT(*) AS total

            FROM predictions

            WHERE risk_category = 'Medium Risk'

        """).fetchone()["total"]


        # ==============================
        # Low Risk
        # ==============================

        low_risk = conn.execute("""

            SELECT COUNT(*) AS total

            FROM predictions

            WHERE risk_category = 'Low Risk'

        """).fetchone()["total"]


        # ==============================
        # Average Attrition Probability
        # ==============================

        average_probability = conn.execute("""

            SELECT AVG(probability) AS average

            FROM predictions

        """).fetchone()["average"]


        # If there are no predictions
        if average_probability is None:

            average_probability = 0


        # ==============================
        # Department-wise Data
        # ==============================

        department_data = conn.execute("""

            SELECT

                department,

                COUNT(*) AS total,

                SUM(
                    CASE
                        WHEN prediction = 'Likely to Leave'
                        THEN 1
                        ELSE 0
                    END
                ) AS leave_count,

                SUM(
                    CASE
                        WHEN prediction = 'Likely to Stay'
                        THEN 1
                        ELSE 0
                    END
                ) AS stay_count

            FROM predictions

            GROUP BY department

            ORDER BY total DESC

        """).fetchall()


        # ==============================
        # Risk-wise Data
        # ==============================

        risk_data = conn.execute("""

            SELECT

                risk_category,

                COUNT(*) AS total

            FROM predictions

            GROUP BY risk_category

        """).fetchall()


        # ==============================
        # Overtime Data
        # ==============================

        overtime_data = conn.execute("""

            SELECT

                overtime,

                COUNT(*) AS total

            FROM predictions

            GROUP BY overtime

        """).fetchall()


        # ==============================
        # Recent Predictions
        # ==============================

        recent_predictions = conn.execute("""

            SELECT

                age,

                monthly_income,

                department,

                prediction,

                probability,

                risk_category,

                created_at

            FROM predictions

            ORDER BY id DESC

            LIMIT 10

        """).fetchall()


        conn.close()


        # ==============================
        # Convert Database Rows
        # ==============================

        departments = []


        for row in department_data:

            departments.append({

                "department":
                row["department"],

                "total":
                row["total"],

                "leave":
                row["leave_count"],

                "stay":
                row["stay_count"]

            })


        risks = []


        for row in risk_data:

            risks.append({

                "risk":
                row["risk_category"],

                "total":
                row["total"]

            })


        overtime = []


        for row in overtime_data:

            overtime.append({

                "overtime":
                row["overtime"],

                "total":
                row["total"]

            })


        recent = []


        for row in recent_predictions:

            recent.append({

                "age":
                row["age"],

                "monthly_income":
                row["monthly_income"],

                "department":
                row["department"],

                "prediction":
                row["prediction"],

                "probability":
                row["probability"],

                "risk":
                row["risk_category"],

                "created_at":
                row["created_at"]

            })


        # ==============================
        # Dashboard Response
        # ==============================

        return jsonify({

            "success": True,

            "summary": {

                "total_predictions":
                total_predictions,

                "likely_to_leave":
                likely_to_leave,

                "likely_to_stay":
                likely_to_stay,

                "high_risk":
                high_risk,

                "medium_risk":
                medium_risk,

                "low_risk":
                low_risk,

                "average_probability":
                round(
                    average_probability,
                    2
                )

            },

            "departments":
            departments,

            "risks":
            risks,

            "overtime":
            overtime,

            "recent_predictions":
            recent

        })


    except Exception as e:

        return jsonify({

            "success": False,

            "error": str(e)

        }), 500


# ==============================
# Contact Form API
# ==============================

@app.route("/contact", methods=["POST"])
def contact():

    try:

        data = request.get_json()


        if not data:

            return jsonify({

                "success": False,

                "error":
                "No data received."

            }), 400


        name = data.get(
            "name",
            ""
        ).strip()


        email = data.get(
            "email",
            ""
        ).strip()


        subject = data.get(
            "subject",
            ""
        ).strip()


        message = data.get(
            "message",
            ""
        ).strip()


        # ==============================
        # Validate Contact Form
        # ==============================

        if (
            not name
            or not email
            or not subject
            or not message
        ):

            return jsonify({

                "success": False,

                "error":
                "Please fill in all fields."

            }), 400


        # Display in Flask terminal

        print(
            "\n========== NEW CONTACT MESSAGE =========="
        )

        print(
            "Name:",
            name
        )

        print(
            "Email:",
            email
        )

        print(
            "Subject:",
            subject
        )

        print(
            "Message:",
            message
        )

        print(
            "=========================================\n"
        )


        return jsonify({

            "success": True,

            "message":
            "Thank you! Your message has been submitted successfully."

        })


    except Exception as e:

        return jsonify({

            "success": False,

            "error": str(e)

        }), 500


# ==============================
# Frontend Files
# ==============================

@app.route("/<path:filename>")
def frontend_files(filename):

    return send_from_directory(
        "frontend",
        filename
    )


# ==============================
# Run Flask Application
# ==============================

if __name__ == "__main__":

    app.run(debug=True)