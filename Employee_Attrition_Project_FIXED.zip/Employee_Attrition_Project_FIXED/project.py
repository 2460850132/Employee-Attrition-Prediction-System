import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score
)
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier


# ==========================================
# 1. LOAD DATASET
# ==========================================

df = pd.read_csv("HR_Analytics_Cleaned.csv")

print("Dataset Shape:", df.shape)


# ==========================================
# 2. PREPARE DATA
# ==========================================

# Convert Attrition Yes/No into 1/0
df["Attrition"] = df["Attrition"].map({
    "Yes": 1,
    "No": 0
})

# Separate input and target
X = df.drop("Attrition", axis=1)
y = df["Attrition"]

# Convert categorical columns into numbers
X = pd.get_dummies(X, drop_first=True)

# Fill missing values
X = X.fillna(X.median(numeric_only=True))

# Make sure any remaining missing values are filled
X = X.fillna(0)


# ==========================================
# 3. TRAIN / TEST SPLIT
# ==========================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

print("\nTraining Data Shape:", X_train.shape)
print("Testing Data Shape:", X_test.shape)


# ==========================================
# 4. LOGISTIC REGRESSION
# ==========================================

logistic_model = LogisticRegression(
    max_iter=5000,
    class_weight="balanced",
    solver="liblinear"
)

logistic_model.fit(X_train, y_train)

y_pred = logistic_model.predict(X_test)
y_prob = logistic_model.predict_proba(X_test)[:, 1]

print("\n--- Logistic Regression ---")

print("Accuracy :", accuracy_score(y_test, y_pred))
print("Precision:", precision_score(y_test, y_pred))
print("Recall   :", recall_score(y_test, y_pred))
print("F1 Score :", f1_score(y_test, y_pred))
print("ROC-AUC  :", roc_auc_score(y_test, y_prob))


# ==========================================
# 5. DECISION TREE
# ==========================================

decision_tree = DecisionTreeClassifier(
    random_state=42,
    max_depth=5
)

decision_tree.fit(X_train, y_train)

y_pred_dt = decision_tree.predict(X_test)
y_prob_dt = decision_tree.predict_proba(X_test)[:, 1]

print("\n--- Decision Tree ---")

print("Accuracy :", accuracy_score(y_test, y_pred_dt))
print("Precision:", precision_score(y_test, y_pred_dt))
print("Recall   :", recall_score(y_test, y_pred_dt))
print("F1 Score :", f1_score(y_test, y_pred_dt))
print("ROC-AUC  :", roc_auc_score(y_test, y_prob_dt))


# ==========================================
# 6. RANDOM FOREST
# ==========================================

random_forest = RandomForestClassifier(
    n_estimators=100,
    random_state=42
)

random_forest.fit(X_train, y_train)

y_pred_rf = random_forest.predict(X_test)
y_prob_rf = random_forest.predict_proba(X_test)[:, 1]

print("\n--- Random Forest ---")

print("Accuracy :", accuracy_score(y_test, y_pred_rf))
print("Precision:", precision_score(y_test, y_pred_rf))
print("Recall   :", recall_score(y_test, y_pred_rf))
print("F1 Score :", f1_score(y_test, y_pred_rf))
print("ROC-AUC  :", roc_auc_score(y_test, y_prob_rf))


# ==========================================
# 7. USE LOGISTIC REGRESSION FOR PREDICTION
# ==========================================

print("\n==========================================")
print("EMPLOYEE ATTRITION PREDICTION")
print("==========================================")


# Predict all employees
all_predictions = logistic_model.predict(X)

# Get probability of leaving
all_probabilities = logistic_model.predict_proba(X)[:, 1]


# ==========================================
# 8. CONVERT PREDICTION TO TEXT
# ==========================================

prediction_labels = []

for prediction in all_predictions:

    if prediction == 1:
        prediction_labels.append("Likely to Leave")
    else:
        prediction_labels.append("Likely to Stay")


# ==========================================
# 9. CREATE RISK CATEGORY
# ==========================================

risk_categories = []

for probability in all_probabilities:

    probability_percentage = probability * 100

    if probability_percentage < 30:
        risk_categories.append("Low Risk")

    elif probability_percentage <= 60:
        risk_categories.append("Medium Risk")

    else:
        risk_categories.append("High Risk")


# ==========================================
# 10. ADD RESULTS TO DATASET
# ==========================================

df["Prediction"] = prediction_labels

df["Attrition Probability"] = (
    all_probabilities * 100
)

df["Risk Category"] = risk_categories


# ==========================================
# 11. DISPLAY FINAL COUNTS
# ==========================================

print("\nTotal Employees:", len(df))

print(
    "Likely to Leave:",
    (df["Prediction"] == "Likely to Leave").sum()
)

print(
    "Likely to Stay:",
    (df["Prediction"] == "Likely to Stay").sum()
)


print("\nRisk Category Count:")

print(
    "Low Risk:",
    (df["Risk Category"] == "Low Risk").sum()
)

print(
    "Medium Risk:",
    (df["Risk Category"] == "Medium Risk").sum()
)

print(
    "High Risk:",
    (df["Risk Category"] == "High Risk").sum()
)


# ==========================================
# 12. SAVE PREDICTION CSV
# ==========================================

df.to_csv(
    "Employee_Attrition_Predictions.csv",
    index=False
)

print("\nPrediction file created successfully!")

print(
    "File: Employee_Attrition_Predictions.csv"
)