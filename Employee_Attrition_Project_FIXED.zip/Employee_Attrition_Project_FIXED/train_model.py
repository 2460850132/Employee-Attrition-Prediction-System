import pandas as pd
import pickle

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression


# Load dataset
df = pd.read_csv("HR_Analytics_Cleaned.csv")


# Project required inputs
features = [
    "Age",
    "MonthlyIncome",
    "TotalWorkingYears",
    "Department",
    "JobSatisfaction",
    "OverTime"
]

X = df[features]


# Target
y = (df["Attrition"] == "Yes").astype(int)


# Categorical columns
categorical_features = [
    "Department",
    "OverTime"
]


# Numerical columns
numerical_features = [
    "Age",
    "MonthlyIncome",
    "TotalWorkingYears",
    "JobSatisfaction"
]


# Preprocessing
preprocessor = ColumnTransformer(
    transformers=[
        (
            "categorical",
            OneHotEncoder(handle_unknown="ignore"),
            categorical_features
        ),
        (
            "numerical",
            StandardScaler(),
            numerical_features
        )
    ]
)


# Machine Learning model
model = Pipeline(
    steps=[
        ("preprocessor", preprocessor),
        (
            "classifier",
            LogisticRegression(
                max_iter=1000,
                random_state=42
            )
        )
    ]
)


# Split dataset
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)


# Train model
model.fit(X_train, y_train)


# Check accuracy
accuracy = model.score(X_test, y_test)

print("Model trained successfully!")
print("Accuracy:", accuracy)


# Save model
with open("model.pkl", "wb") as file:
    pickle.dump(model, file)


print("New model.pkl saved successfully!")
